#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="$MODDIR/zram_config.conf"

apply_zram() {
  local alg="$1"
  local size="$2"
  if [ -e /dev/block/zram0 ]; then
    sleep 30

    su -c swapoff /dev/block/zram0
    su -c rmmod zram
    sleep 5
    su -c insmod $MODDIR/zram.ko
    sleep 5
    echo '1' > /sys/block/zram0/reset
    echo '0' > /sys/block/zram0/disksize
    echo "$alg" > /sys/block/zram0/comp_algorithm
    echo "$size" > /sys/block/zram0/disksize
    mkswap /dev/block/zram0 > /dev/null 2>&1
    swapon /dev/block/zram0 > /dev/null 2>&1
  fi
}

if [ -f "$CONFIG" ]; then
  source "$CONFIG"
  [ -n "$algorithm" ] && [ -n "$size" ] && apply_zram "$algorithm" "$size"
fi 