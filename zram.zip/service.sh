#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="$MODDIR/zram_config.conf"
LOG="$MODDIR/zram.log"

# 日志记录函数
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG"
}

# 应用ZRAM配置
apply_zram() {
    local alg="$1"
    local size="$2"
    local try=0
    
    log_message "开始应用ZRAM配置：算法=$alg, 大小=${size}字节"
    
    while [ ! -e /dev/block/zram0 ] && [ $try -lt 60 ]; do
        sleep 1
        try=$((try+1))
    done
    
    if [ ! -e /dev/block/zram0 ]; then
        log_message "错误：无法找到ZRAM设备"
        return 1
    fi
    
    log_message "关闭现有ZRAM设备"
    su -c swapoff /dev/block/zram0
    su -c rmmod zram
    sleep 10

    log_message "加载ZSMALLOC内核模块"
    su -c insmod $MODDIR/zsmalloc.ko
    sleep 10

    log_message "加载ZRAM内核模块"
    su -c insmod $MODDIR/zram.ko
    sleep 10
    
    echo '1' > /sys/block/zram0/reset
    echo '0' > /sys/block/zram0/disksize
    echo "$alg" > /sys/block/zram0/comp_algorithm
    echo "$size" > /sys/block/zram0/disksize
    
    log_message "配置ZRAM设备"
    mkswap /dev/block/zram0 > /dev/null 2>&1
    swapon -p 32758 /dev/block/zram0 > /dev/null 2>&1
    log_message "ZRAM设备配置完成并启用"
}

# 创建日志文件
touch "$LOG"
log_message "ZRAM服务启动"

# 应用配置
if [ -f "$CONFIG" ]; then
    log_message "读取配置文件"
    source "$CONFIG"
    [ -n "$algorithm" ] && [ -n "$size" ] && apply_zram "$algorithm" "$size"
else
    log_message "错误：无法找到配置文件"
fi

resetprop ro.boot.flash.locked 1
resetprop ro.boot.verifiedbootstate green
resetprop ro.secureboot.lockstate locked
resetprop ro.boot.vbmeta.device_state locked
resetprop -n ro.boot.vbmeta.digest